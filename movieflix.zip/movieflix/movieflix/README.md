# MovieFlix


Clone this repo – 

    git clone https://github.com/ARUJANNMEE/movieflix.git

Move into project directory **movieflix**

    command - cd movieflix

Run command – 

    npm install

This will install the node_modules folder

Run command – 

    npm run start-dev

To run project on localhost:3000

# down button word "sign up"